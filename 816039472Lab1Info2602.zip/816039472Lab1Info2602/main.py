from flask import Flask, request, jsonify
import json

app = Flask(__name__)

global data

# read data from file and store in global variable data
with open('data.json') as f:
    data = json.load(f)


@app.route('/students/<id>')
def get_student(id):
  for student in data: 
    if student['id'] == id: # filter out the students without the specified id
      return jsonify(student)
        
@app.route('/students')
def get_students():
  result = []
  pref = request.args.get('pref') 
  if pref:
    for student in data: 
      if student['pref'] == pref: 
        result.append(student) 
    return jsonify(result) 
  return jsonify(data)

@app.route('/')
def hello_world():
    return ' 816039472 Lab 1'  # return 'Hello World' in response

@app.route('/stats')
def get_stats():
    data ={ "Vegetable": "10", "Information Technology(Special)": "18","Information Technology(Major)":"26","Fish": "6","Computer Science(Special)":"37", "Computer Science(Major)":"11","Chicken":"76"}
    return jsonify(data)


@app.route('/add/<int:a>/<int:b>')
def get_add(a, b):
    return {"Request":"addition", 'a': a, 'b': b, 'result': a + b}

@app.route('/subtract/<int:a>/<int:b>')
def subtract(a, b):
    return {"Request": 'subtraction', 'a': a, 'b': b, 'result': a - b}

@app.route('/multiply/<int:a>/<int:b>')
def multiply(a, b):
    return {"Request": 'multiplication', 'a': a, 'b': b, 'result': a * b}

@app.route('/divide/<int:a>/<int:b>')
def divide(a, b):
    if b == 0:
        return {"Error": "Cannot divide by 0"}, 400
    return {'operation': 'division', 'a': a, 'b': b, 'result': a / b}

app.run(host='0.0.0.0', port=8080, debug=True)
if __name__ == '__main__':
    app.run(debug=True)